from app.api.v1.users import api as users_api
from app.api.v1.places import api as places_ns
from app.api.v1.reviews import api as reviews_ns
from app.api.v1.amenities import api as amenities_ns


def register_namespaces(api):
    """
    Register all v1 namespaces into the Flask-RESTX Api instance.
    """
    api.add_namespace(users_api, path="/api/v1/users")
    api.add_namespace(places_ns, path="/api/v1/places")
    api.add_namespace(reviews_ns, path="/api/v1/reviews")
    api.add_namespace(amenities_ns, path="/api/v1/amenities")
